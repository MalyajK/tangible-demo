--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tangible;
--
-- Name: tangible; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE tangible WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE tangible OWNER TO postgres;

\connect tangible

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: notify_new_fundreq(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.notify_new_fundreq() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin 
		perform pg_notify('new_fundreq', row_to_json(NEW)::text);
		return null;
	end;
$$;


ALTER FUNCTION public.notify_new_fundreq() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.addresses (
    address_id integer NOT NULL,
    locality character varying(100) NOT NULL,
    street character varying(100) NOT NULL,
    building character varying(100) NOT NULL,
    landmark character varying(100),
    zip_code character varying(6),
    city_id integer
);


ALTER TABLE public.addresses OWNER TO postgres;

--
-- Name: addresses_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.addresses_address_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.addresses_address_id_seq OWNER TO postgres;

--
-- Name: addresses_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.addresses_address_id_seq OWNED BY public.addresses.address_id;


--
-- Name: budget; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget (
    budget_id integer NOT NULL,
    department integer,
    division integer,
    region integer,
    monthly jsonb,
    expense_head character varying(50),
    annual bigint GENERATED ALWAYS AS (((((((((((((((monthly -> 0) ->> 'JAN'::text))::integer + (((monthly -> 0) ->> 'FEB'::text))::integer) + (((monthly -> 0) ->> 'MAR'::text))::integer) + (((monthly -> 0) ->> 'APR'::text))::integer) + (((monthly -> 0) ->> 'MAY'::text))::integer) + (((monthly -> 0) ->> 'JUN'::text))::integer) + (((monthly -> 0) ->> 'JUL'::text))::integer) + (((monthly -> 0) ->> 'AUG'::text))::integer) + (((monthly -> 0) ->> 'SEP'::text))::integer) + (((monthly -> 0) ->> 'OCT'::text))::integer) + (((monthly -> 0) ->> 'NOV'::text))::integer) + (((monthly -> 0) ->> 'DEC'::text))::integer)) STORED
);


ALTER TABLE public.budget OWNER TO postgres;

--
-- Name: budget_budget_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_budget_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.budget_budget_id_seq OWNER TO postgres;

--
-- Name: budget_budget_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_budget_id_seq OWNED BY public.budget.budget_id;


--
-- Name: chats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chats (
    chat_id integer NOT NULL,
    is_private boolean,
    creator integer,
    receiver integer[] NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.chats OWNER TO postgres;

--
-- Name: chats_chat_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.chats_chat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chats_chat_id_seq OWNER TO postgres;

--
-- Name: chats_chat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.chats_chat_id_seq OWNED BY public.chats.chat_id;


--
-- Name: cities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cities (
    city_id integer NOT NULL,
    city_name character varying(50) NOT NULL,
    state character varying(50) NOT NULL,
    country character varying(50) NOT NULL
);


ALTER TABLE public.cities OWNER TO postgres;

--
-- Name: cities_city_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cities_city_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cities_city_id_seq OWNER TO postgres;

--
-- Name: cities_city_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cities_city_id_seq OWNED BY public.cities.city_id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    customer_id integer NOT NULL,
    customer_name character varying(50) NOT NULL,
    country character varying(50) NOT NULL,
    state character varying(50) NOT NULL,
    city character varying(50) NOT NULL,
    address character varying(50) NOT NULL,
    email character varying(50) NOT NULL,
    phone character varying(50) NOT NULL,
    contact character varying(50) NOT NULL,
    tax_number character varying(50) NOT NULL,
    industry character varying(50) NOT NULL
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_customer_id_seq OWNER TO postgres;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_customer_id_seq OWNED BY public.customers.customer_id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departments (
    department_id integer NOT NULL,
    department_name character varying(100) NOT NULL,
    department_head integer,
    small_name character varying(30),
    dashboard_name character varying(30)
);


ALTER TABLE public.departments OWNER TO postgres;

--
-- Name: departments_department_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.departments_department_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departments_department_id_seq OWNER TO postgres;

--
-- Name: departments_department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.departments_department_id_seq OWNED BY public.departments.department_id;


--
-- Name: divisions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.divisions (
    division_id integer NOT NULL,
    division_name character varying(50) NOT NULL
);


ALTER TABLE public.divisions OWNER TO postgres;

--
-- Name: divisions_division_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.divisions_division_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.divisions_division_id_seq OWNER TO postgres;

--
-- Name: divisions_division_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.divisions_division_id_seq OWNED BY public.divisions.division_id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    event_id integer NOT NULL,
    event_type character varying(20),
    event_title character varying(100),
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    event_creator integer,
    invitees integer[],
    is_live boolean
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: events_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.events_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_event_id_seq OWNER TO postgres;

--
-- Name: events_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.events_event_id_seq OWNED BY public.events.event_id;


--
-- Name: fund_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fund_requests (
    request_id integer NOT NULL,
    budgeted boolean,
    project_id integer,
    description character varying(100),
    initiator integer,
    expense_head character varying(50),
    assign_to character varying(10),
    task_id integer,
    frequency character varying(20),
    amount bigint,
    starting character varying(10),
    department integer,
    required_by date,
    status character varying(20),
    created_at timestamp with time zone DEFAULT now(),
    comments jsonb
);


ALTER TABLE public.fund_requests OWNER TO postgres;

--
-- Name: fund_requests_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fund_requests_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fund_requests_request_id_seq OWNER TO postgres;

--
-- Name: fund_requests_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fund_requests_request_id_seq OWNED BY public.fund_requests.request_id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    invoice_id integer NOT NULL,
    division integer NOT NULL,
    invoice_number character varying(50) NOT NULL,
    invoice_date date NOT NULL,
    customer_id integer NOT NULL,
    invoice_amount bigint NOT NULL,
    amount_received bigint,
    due_date date GENERATED ALWAYS AS ((invoice_date + 30)) STORED,
    outstanding bigint GENERATED ALWAYS AS ((invoice_amount - amount_received)) STORED NOT NULL,
    sales_person integer
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: invoices_invoice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoices_invoice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoices_invoice_id_seq OWNER TO postgres;

--
-- Name: invoices_invoice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoices_invoice_id_seq OWNED BY public.invoices.invoice_id;


--
-- Name: leads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leads (
    lead_id integer NOT NULL,
    customer_type character varying(10) NOT NULL,
    customer_id integer,
    division integer,
    assignee integer,
    prospect character varying(100),
    region character varying(50) NOT NULL,
    source character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    pipeline json,
    created_on timestamp with time zone DEFAULT now(),
    created_by integer NOT NULL,
    likelihood integer,
    total_pipeline bigint GENERATED ALWAYS AS ((((((((((((((pipeline ->> 'January'::text))::integer + ((pipeline ->> 'February'::text))::integer) + ((pipeline ->> 'March'::text))::integer) + ((pipeline ->> 'April'::text))::integer) + ((pipeline ->> 'May'::text))::integer) + ((pipeline ->> 'June'::text))::integer) + ((pipeline ->> 'July'::text))::integer) + ((pipeline ->> 'August'::text))::integer) + ((pipeline ->> 'September'::text))::integer) + ((pipeline ->> 'October'::text))::integer) + ((pipeline ->> 'November'::text))::integer) + ((pipeline ->> 'December'::text))::integer)) STORED
);


ALTER TABLE public.leads OWNER TO postgres;

--
-- Name: leads_lead_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.leads_lead_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.leads_lead_id_seq OWNER TO postgres;

--
-- Name: leads_lead_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.leads_lead_id_seq OWNED BY public.leads.lead_id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    message_id integer NOT NULL,
    chat_id integer,
    sender integer,
    created_at timestamp without time zone DEFAULT now(),
    message character varying(3000)
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: message_message_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.message_message_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.message_message_id_seq OWNER TO postgres;

--
-- Name: message_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.message_message_id_seq OWNED BY public.messages.message_id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    notification_id integer NOT NULL,
    trigger character varying(50),
    recipients jsonb,
    created_at timestamp without time zone DEFAULT now(),
    document_id integer
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_notification_id_seq OWNER TO postgres;

--
-- Name: notifications_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_notification_id_seq OWNED BY public.notifications.notification_id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    project_id integer NOT NULL,
    project_title character varying(100) NOT NULL,
    project_description character varying(255) NOT NULL,
    created_by integer,
    assignee integer,
    start_date date NOT NULL,
    end_date date NOT NULL,
    project_budget bigint
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: projects_project_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.projects_project_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_project_id_seq OWNER TO postgres;

--
-- Name: projects_project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.projects_project_id_seq OWNED BY public.projects.project_id;


--
-- Name: sales_region; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_region (
    region_id integer NOT NULL,
    region_name character varying(50)
);


ALTER TABLE public.sales_region OWNER TO postgres;

--
-- Name: sales_region_region_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_region_region_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sales_region_region_id_seq OWNER TO postgres;

--
-- Name: sales_region_region_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_region_region_id_seq OWNED BY public.sales_region.region_id;


--
-- Name: sales_target; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_target (
    customer_id integer,
    division integer,
    month integer,
    target integer,
    monthly_targets json,
    target_id integer NOT NULL,
    annual_target bigint GENERATED ALWAYS AS ((((((((((((((monthly_targets ->> 'JAN'::text))::integer + ((monthly_targets ->> 'FEB'::text))::integer) + ((monthly_targets ->> 'MAR'::text))::integer) + ((monthly_targets ->> 'APR'::text))::integer) + ((monthly_targets ->> 'MAY'::text))::integer) + ((monthly_targets ->> 'JUN'::text))::integer) + ((monthly_targets ->> 'JUL'::text))::integer) + ((monthly_targets ->> 'AUG'::text))::integer) + ((monthly_targets ->> 'SEP'::text))::integer) + ((monthly_targets ->> 'OCT'::text))::integer) + ((monthly_targets ->> 'NOV'::text))::integer) + ((monthly_targets ->> 'DEC'::text))::integer)) STORED,
    jan bigint GENERATED ALWAYS AS (((monthly_targets ->> 'JAN'::text))::integer) STORED,
    feb bigint GENERATED ALWAYS AS (((monthly_targets ->> 'FEB'::text))::integer) STORED,
    mar bigint GENERATED ALWAYS AS (((monthly_targets ->> 'MAR'::text))::integer) STORED,
    apr bigint GENERATED ALWAYS AS (((monthly_targets ->> 'APR'::text))::integer) STORED,
    may bigint GENERATED ALWAYS AS (((monthly_targets ->> 'MAY'::text))::integer) STORED,
    jun bigint GENERATED ALWAYS AS (((monthly_targets ->> 'JUN'::text))::integer) STORED,
    jul bigint GENERATED ALWAYS AS (((monthly_targets ->> 'JUL'::text))::integer) STORED,
    aug bigint GENERATED ALWAYS AS (((monthly_targets ->> 'AUG'::text))::integer) STORED,
    sep bigint GENERATED ALWAYS AS (((monthly_targets ->> 'SEP'::text))::integer) STORED,
    oct bigint GENERATED ALWAYS AS (((monthly_targets ->> 'OCT'::text))::integer) STORED,
    nov bigint GENERATED ALWAYS AS (((monthly_targets ->> 'NOV'::text))::integer) STORED,
    "dec" bigint GENERATED ALWAYS AS (((monthly_targets ->> 'DEC'::text))::integer) STORED,
    sales_person integer
);


ALTER TABLE public.sales_target OWNER TO postgres;

--
-- Name: sales_target_target_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_target_target_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sales_target_target_id_seq OWNER TO postgres;

--
-- Name: sales_target_target_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_target_target_id_seq OWNED BY public.sales_target.target_id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tasks (
    task_id integer NOT NULL,
    task_title character varying(100) NOT NULL,
    task_description character varying(255) NOT NULL,
    project_id integer,
    created_by integer,
    assignee integer,
    start_date date NOT NULL,
    end_date date NOT NULL,
    completion integer,
    task_status character varying,
    is_public boolean,
    measure_type character varying(20),
    target numeric,
    weight integer
);


ALTER TABLE public.tasks OWNER TO postgres;

--
-- Name: tasks_task_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tasks_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_task_id_seq OWNER TO postgres;

--
-- Name: tasks_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tasks_task_id_seq OWNED BY public.tasks.task_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    address_id integer,
    department_id integer,
    created_on timestamp without time zone NOT NULL,
    mobile_no character varying(10) NOT NULL,
    password character varying,
    manager integer,
    full_name character varying(101) GENERATED ALWAYS AS (
CASE
    WHEN (first_name IS NULL) THEN (last_name)::text
    WHEN (last_name IS NULL) THEN (first_name)::text
    ELSE (((first_name)::text || ' '::text) || (last_name)::text)
END) STORED,
    fixed_salary integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: addresses address_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addresses ALTER COLUMN address_id SET DEFAULT nextval('public.addresses_address_id_seq'::regclass);


--
-- Name: budget budget_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget ALTER COLUMN budget_id SET DEFAULT nextval('public.budget_budget_id_seq'::regclass);


--
-- Name: chats chat_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chats ALTER COLUMN chat_id SET DEFAULT nextval('public.chats_chat_id_seq'::regclass);


--
-- Name: cities city_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cities ALTER COLUMN city_id SET DEFAULT nextval('public.cities_city_id_seq'::regclass);


--
-- Name: customers customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN customer_id SET DEFAULT nextval('public.customers_customer_id_seq'::regclass);


--
-- Name: departments department_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments ALTER COLUMN department_id SET DEFAULT nextval('public.departments_department_id_seq'::regclass);


--
-- Name: divisions division_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.divisions ALTER COLUMN division_id SET DEFAULT nextval('public.divisions_division_id_seq'::regclass);


--
-- Name: events event_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events ALTER COLUMN event_id SET DEFAULT nextval('public.events_event_id_seq'::regclass);


--
-- Name: fund_requests request_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fund_requests ALTER COLUMN request_id SET DEFAULT nextval('public.fund_requests_request_id_seq'::regclass);


--
-- Name: invoices invoice_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices ALTER COLUMN invoice_id SET DEFAULT nextval('public.invoices_invoice_id_seq'::regclass);


--
-- Name: leads lead_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads ALTER COLUMN lead_id SET DEFAULT nextval('public.leads_lead_id_seq'::regclass);


--
-- Name: messages message_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages ALTER COLUMN message_id SET DEFAULT nextval('public.message_message_id_seq'::regclass);


--
-- Name: notifications notification_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN notification_id SET DEFAULT nextval('public.notifications_notification_id_seq'::regclass);


--
-- Name: projects project_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects ALTER COLUMN project_id SET DEFAULT nextval('public.projects_project_id_seq'::regclass);


--
-- Name: sales_region region_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_region ALTER COLUMN region_id SET DEFAULT nextval('public.sales_region_region_id_seq'::regclass);


--
-- Name: sales_target target_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_target ALTER COLUMN target_id SET DEFAULT nextval('public.sales_target_target_id_seq'::regclass);


--
-- Name: tasks task_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks ALTER COLUMN task_id SET DEFAULT nextval('public.tasks_task_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.addresses (address_id, locality, street, building, landmark, zip_code, city_id) FROM stdin;
\.
COPY public.addresses (address_id, locality, street, building, landmark, zip_code, city_id) FROM '$$PATH$$/3470.dat';

--
-- Data for Name: budget; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget (budget_id, department, division, region, monthly, expense_head) FROM stdin;
\.
COPY public.budget (budget_id, department, division, region, monthly, expense_head) FROM '$$PATH$$/3496.dat';

--
-- Data for Name: chats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chats (chat_id, is_private, creator, receiver, created_at) FROM stdin;
\.
COPY public.chats (chat_id, is_private, creator, receiver, created_at) FROM '$$PATH$$/3500.dat';

--
-- Data for Name: cities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cities (city_id, city_name, state, country) FROM stdin;
\.
COPY public.cities (city_id, city_name, state, country) FROM '$$PATH$$/3468.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (customer_id, customer_name, country, state, city, address, email, phone, contact, tax_number, industry) FROM stdin;
\.
COPY public.customers (customer_id, customer_name, country, state, city, address, email, phone, contact, tax_number, industry) FROM '$$PATH$$/3480.dat';

--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departments (department_id, department_name, department_head, small_name, dashboard_name) FROM stdin;
\.
COPY public.departments (department_id, department_name, department_head, small_name, dashboard_name) FROM '$$PATH$$/3472.dat';

--
-- Data for Name: divisions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.divisions (division_id, division_name) FROM stdin;
\.
COPY public.divisions (division_id, division_name) FROM '$$PATH$$/3482.dat';

--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events (event_id, event_type, event_title, start_time, end_time, event_creator, invitees, is_live) FROM stdin;
\.
COPY public.events (event_id, event_type, event_title, start_time, end_time, event_creator, invitees, is_live) FROM '$$PATH$$/3492.dat';

--
-- Data for Name: fund_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fund_requests (request_id, budgeted, project_id, description, initiator, expense_head, assign_to, task_id, frequency, amount, starting, department, required_by, status, created_at, comments) FROM stdin;
\.
COPY public.fund_requests (request_id, budgeted, project_id, description, initiator, expense_head, assign_to, task_id, frequency, amount, starting, department, required_by, status, created_at, comments) FROM '$$PATH$$/3494.dat';

--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (invoice_id, division, invoice_number, invoice_date, customer_id, invoice_amount, amount_received, sales_person) FROM stdin;
\.
COPY public.invoices (invoice_id, division, invoice_number, invoice_date, customer_id, invoice_amount, amount_received, sales_person) FROM '$$PATH$$/3484.dat';

--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leads (lead_id, customer_type, customer_id, division, assignee, prospect, region, source, status, pipeline, created_on, created_by, likelihood) FROM stdin;
\.
COPY public.leads (lead_id, customer_type, customer_id, division, assignee, prospect, region, source, status, pipeline, created_on, created_by, likelihood) FROM '$$PATH$$/3487.dat';

--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (message_id, chat_id, sender, created_at, message) FROM stdin;
\.
COPY public.messages (message_id, chat_id, sender, created_at, message) FROM '$$PATH$$/3502.dat';

--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (notification_id, trigger, recipients, created_at, document_id) FROM stdin;
\.
COPY public.notifications (notification_id, trigger, recipients, created_at, document_id) FROM '$$PATH$$/3498.dat';

--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (project_id, project_title, project_description, created_by, assignee, start_date, end_date, project_budget) FROM stdin;
\.
COPY public.projects (project_id, project_title, project_description, created_by, assignee, start_date, end_date, project_budget) FROM '$$PATH$$/3476.dat';

--
-- Data for Name: sales_region; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_region (region_id, region_name) FROM stdin;
\.
COPY public.sales_region (region_id, region_name) FROM '$$PATH$$/3490.dat';

--
-- Data for Name: sales_target; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_target (customer_id, division, month, target, monthly_targets, target_id, sales_person) FROM stdin;
\.
COPY public.sales_target (customer_id, division, month, target, monthly_targets, target_id, sales_person) FROM '$$PATH$$/3485.dat';

--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tasks (task_id, task_title, task_description, project_id, created_by, assignee, start_date, end_date, completion, task_status, is_public, measure_type, target, weight) FROM stdin;
\.
COPY public.tasks (task_id, task_title, task_description, project_id, created_by, assignee, start_date, end_date, completion, task_status, is_public, measure_type, target, weight) FROM '$$PATH$$/3478.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, first_name, last_name, email, address_id, department_id, created_on, mobile_no, password, manager, fixed_salary) FROM stdin;
\.
COPY public.users (user_id, first_name, last_name, email, address_id, department_id, created_on, mobile_no, password, manager, fixed_salary) FROM '$$PATH$$/3474.dat';

--
-- Name: addresses_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.addresses_address_id_seq', 5, true);


--
-- Name: budget_budget_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_budget_id_seq', 1260, true);


--
-- Name: chats_chat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.chats_chat_id_seq', 44, true);


--
-- Name: cities_city_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cities_city_id_seq', 6, true);


--
-- Name: customers_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_customer_id_seq', 50, true);


--
-- Name: departments_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.departments_department_id_seq', 9, true);


--
-- Name: divisions_division_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.divisions_division_id_seq', 5, true);


--
-- Name: events_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.events_event_id_seq', 64, true);


--
-- Name: fund_requests_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fund_requests_request_id_seq', 21, true);


--
-- Name: invoices_invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoices_invoice_id_seq', 81, true);


--
-- Name: leads_lead_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.leads_lead_id_seq', 16, true);


--
-- Name: message_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.message_message_id_seq', 112, true);


--
-- Name: notifications_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_notification_id_seq', 1, false);


--
-- Name: projects_project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.projects_project_id_seq', 44, true);


--
-- Name: sales_region_region_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_region_region_id_seq', 4, true);


--
-- Name: sales_target_target_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_target_target_id_seq', 601, true);


--
-- Name: tasks_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tasks_task_id_seq', 84, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 212, true);


--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (address_id);


--
-- Name: budget budget_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget
    ADD CONSTRAINT budget_pkey PRIMARY KEY (budget_id);


--
-- Name: chats chats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_pkey PRIMARY KEY (chat_id);


--
-- Name: cities cities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT cities_pkey PRIMARY KEY (city_id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (customer_id);


--
-- Name: departments departments_department_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_department_name_key UNIQUE (department_name);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (department_id);


--
-- Name: divisions divisions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.divisions
    ADD CONSTRAINT divisions_pkey PRIMARY KEY (division_id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (event_id);


--
-- Name: fund_requests fund_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fund_requests
    ADD CONSTRAINT fund_requests_pkey PRIMARY KEY (request_id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (invoice_id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (lead_id);


--
-- Name: messages message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT message_pkey PRIMARY KEY (message_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (notification_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (project_id);


--
-- Name: sales_region sales_region_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_region
    ADD CONSTRAINT sales_region_pkey PRIMARY KEY (region_id);


--
-- Name: sales_target sales_target_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_target
    ADD CONSTRAINT sales_target_pkey PRIMARY KEY (target_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (task_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: fund_requests notify_new_fundreq; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER notify_new_fundreq AFTER INSERT ON public.fund_requests FOR EACH ROW EXECUTE FUNCTION public.notify_new_fundreq();


--
-- Name: addresses addresses_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_city_id_fkey FOREIGN KEY (city_id) REFERENCES public.cities(city_id);


--
-- Name: budget budget_department_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget
    ADD CONSTRAINT budget_department_fkey FOREIGN KEY (department) REFERENCES public.departments(department_id);


--
-- Name: budget budget_division_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget
    ADD CONSTRAINT budget_division_fkey FOREIGN KEY (division) REFERENCES public.divisions(division_id);


--
-- Name: budget budget_region_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget
    ADD CONSTRAINT budget_region_fkey FOREIGN KEY (region) REFERENCES public.sales_region(region_id);


--
-- Name: chats chats_sender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_sender_fkey FOREIGN KEY (creator) REFERENCES public.users(user_id);


--
-- Name: departments departments_department_head_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_department_head_fkey FOREIGN KEY (department_head) REFERENCES public.users(user_id);


--
-- Name: events events_event_creator_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_event_creator_fkey FOREIGN KEY (event_creator) REFERENCES public.users(user_id);


--
-- Name: leads fk_lead_creator; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT fk_lead_creator FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: fund_requests fund_requests_department_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fund_requests
    ADD CONSTRAINT fund_requests_department_fkey FOREIGN KEY (department) REFERENCES public.departments(department_id);


--
-- Name: fund_requests fund_requests_initiator_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fund_requests
    ADD CONSTRAINT fund_requests_initiator_fkey FOREIGN KEY (initiator) REFERENCES public.users(user_id);


--
-- Name: fund_requests fund_requests_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fund_requests
    ADD CONSTRAINT fund_requests_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(project_id);


--
-- Name: fund_requests fund_requests_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fund_requests
    ADD CONSTRAINT fund_requests_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(task_id);


--
-- Name: invoices invoices_sales_person_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_sales_person_fkey FOREIGN KEY (sales_person) REFERENCES public.users(user_id);


--
-- Name: leads leads_assignee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_assignee_fkey FOREIGN KEY (assignee) REFERENCES public.users(user_id);


--
-- Name: leads leads_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(customer_id);


--
-- Name: leads leads_division_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_division_fkey FOREIGN KEY (division) REFERENCES public.divisions(division_id);


--
-- Name: messages message_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT message_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(chat_id);


--
-- Name: messages message_sender_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT message_sender_fkey FOREIGN KEY (sender) REFERENCES public.users(user_id);


--
-- Name: projects projects_assignee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_assignee_fkey FOREIGN KEY (assignee) REFERENCES public.users(user_id);


--
-- Name: projects projects_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: sales_target sales_target_sales_person_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_target
    ADD CONSTRAINT sales_target_sales_person_fkey FOREIGN KEY (sales_person) REFERENCES public.users(user_id);


--
-- Name: tasks tasks_assignee_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assignee_fkey FOREIGN KEY (assignee) REFERENCES public.users(user_id);


--
-- Name: tasks tasks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: tasks tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(project_id);


--
-- Name: users users_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.addresses(address_id);


--
-- Name: users users_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(department_id);


--
-- PostgreSQL database dump complete
--

